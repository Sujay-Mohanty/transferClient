package com.boot.spring.aop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSpringAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootSpringAopApplication.class, args);
	}

}
