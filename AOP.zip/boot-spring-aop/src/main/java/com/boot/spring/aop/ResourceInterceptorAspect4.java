package com.boot.spring.aop;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.boot.spring.aop.resource.Product;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class ResourceInterceptorAspect4 {
	@Pointcut("within(com.boot.spring.aop.controller..*)")
	//controller package given inside execution
	//.* -> Targetting all the classes
	//.* -> Targetting all the methods
	//(..) -> Having one or more arguements
	public void loggingPointCut() {}
	
	@Around("loggingPointCut()")
	//Invoked before and also after the code executes
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable{
		
		log.info("4th TIME -1Before method invoked:: "+ joinPoint.getSignature());	
		log.info("4th TIME -2Before method invoked:: "+ joinPoint.getArgs()[0]);
		
		Object object=joinPoint.proceed();
		
		
		if(object instanceof Product)
			log.info("4th time -3: After Method invoked :: "+joinPoint.getSignature());
		log.info("4th TIME -4 After method invoked:: "+ joinPoint.getArgs()[0]);
		return object;
	}
}
