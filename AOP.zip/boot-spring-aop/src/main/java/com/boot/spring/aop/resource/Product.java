package com.boot.spring.aop.resource;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Product {
private int pid;
private String description;
private double price;
}
