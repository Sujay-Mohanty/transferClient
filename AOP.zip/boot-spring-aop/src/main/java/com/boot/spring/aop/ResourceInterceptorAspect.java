package com.boot.spring.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class ResourceInterceptorAspect {

	
	@Pointcut("execution( * com.boot.spring.aop.controller.*.*(..))")
	//controller package given inside execution
	//.* -> Targetting all the classes
	//.* -> Targetting all the methods
	//(..) -> Having one or more arguements
	public void loggingPointCut() {}
	//Method name used to link join point to Advice
	
	@Before("loggingPointCut()")
	public void before(JoinPoint joinPoint) {
		
		log.info("Before method invoked:: "+ joinPoint.getSignature());	}
	
	@After("loggingPointCut()")
	public void after(JoinPoint joinPoint) {
		log.info("After method invoked:: "+ joinPoint.getSignature());
	}
}
