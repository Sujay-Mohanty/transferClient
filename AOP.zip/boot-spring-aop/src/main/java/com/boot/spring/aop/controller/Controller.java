package com.boot.spring.aop.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.spring.aop.resource.Product;

@RestController
@RequestMapping("/")
public class Controller {

	@GetMapping("/aspect1")
	public String ret() {
		return "hello";
	}
	@GetMapping("/aspect2a")
	public Product getproduct() {
		return new Product(101,"abc",100.00);
	}
	@GetMapping("/aspect2b")
	public Product getproductError() {
		throw new RuntimeException("from fetch");
	}
	@GetMapping("/aspect3/name/{fullname}")
	public String getName(@PathVariable String fullname) {
		return "Hello"+fullname;
	}
	
}
