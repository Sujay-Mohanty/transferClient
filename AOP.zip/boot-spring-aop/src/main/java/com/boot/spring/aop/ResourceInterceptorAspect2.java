package com.boot.spring.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.boot.spring.aop.resource.Product;

import lombok.extern.slf4j.Slf4j;
@Aspect
@Component
@Slf4j
public class ResourceInterceptorAspect2 {

	
	@AfterReturning(value = "execution( * com.boot.spring.aop.controller.*.*(..))",returning="product")
	public void afterRet(JoinPoint joinPoint,Product product)
	{
		
		log.info("(SUJAY) After returning method invoked:: "+ joinPoint.getSignature());	}
	
	@AfterThrowing(value = "execution( * com.boot.spring.aop.resource.*.*(..))",throwing="e")
	public void afterThrow(JoinPoint joinPoint, Exception e) {
		log.info("After method invoked:: "+ e);
	}
}
