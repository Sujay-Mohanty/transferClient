package com.spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SukrutRestClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
