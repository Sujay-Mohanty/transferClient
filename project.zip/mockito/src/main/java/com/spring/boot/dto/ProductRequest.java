package com.spring.boot.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class ProductRequest {
    private long id;
    @NotNull(message="Name cannot be null")
    @NotBlank(message="Name cannot be Blank")
    private String name;
    
    @NotBlank(message="description cannot be Blank")
    private String description;
    
    @Min(value= 1, message="Value cannot be less than 1")
    @Max(value= 10000, message="Value cannot be more than 10000")
    private int quantity;
    
    @NotNull()    
    private double price;

}