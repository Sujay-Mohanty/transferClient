package com.spring.boot.exceptions;

public class InvalidValueException extends Exception {
	public InvalidValueException(String message) {
		super(message);
	}
}
