package com.spring.boot.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

@Service
public class DiscountService {
/**
 * Thanksgiving - 15%
 * Christmas - 50% in 2025 (No discount in other years)
 * @param amount
 * @param season
 */
	public double computeDiscount(double amount,String season){
		int year=LocalDateTime.now().getYear();
		if(season.equals("THANKSGIVING")){return amount*0.15;}
		else if(season.equals("CHRISTMAS")&& year==2025) {return amount*0.5;}
		else {
			return 0;
		}
		
	}
}
