package com.spring.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.boot.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long>{
	//This Repository is for Product Class Entity and the Type of Primary Key is Long
	//Repository is basically to point to the DB Operations for the "Product" Entity
	
	public Product findByName(String name);
	//public Product findByNameAndPrice(String name,Double p);
	public List<Product> findByPriceBetween(double p, double p2);
	
	public List<Product> findByQuantityLessThan(int q);
	
	public List<Product> findByQuantityIn(List<Integer> q);
	
	public List<Product> findByNameInOrderByPriceDesc(List<String> name);
	
	public List<Product> findByNameLike(String q);
	
	@Query("SELECT p FROM Product p")
	List<Product> findAll();
	//p is the alias
	
//	@Query("select p from Product p where p.name like %?1%")
//	List<Product> findByNameLike(String q);
	
//	public List<Product> 
}

 