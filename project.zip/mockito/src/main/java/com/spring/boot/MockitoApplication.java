package com.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoApplication {
//implements CommandLineRunner {
//	@Autowired
//	ProductRepository prodrep;

	public static void main(String[] args) {
		SpringApplication.run(MockitoApplication.class, args);
		
			}

//	@Override
//	public void run(String... args) throws Exception {
//		// TODO Auto-generated method stub
//		prodrep.save(new Product(20,"Rajeev hehe","Rajeev", 1,10));
////		prodrep.save(new Product());
//	}
	

//	@Override
//	public void run(String... args)throws Exception{
//		
//	}
	
//	@Bean
	//1.Java Configuration 
	//2.It can only be present in a classes that are annoted with the @Configuration
//	CommandLineRunner commandLineRunner(ProductRepository repo) {
//		return args -> {
//			Product p1=Product.builder().name("Galaxy J7").description("A galaxy prod").quantity(15).price(78000).build();


//			repo.save(p1);
		
//	};
//	}
}


