package com.spring.boot.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalExceptionHandler 
//extends ResponseEntityExceptionHandler
{

//	@ExceptionHandler(value= {NullPointerException.class})
//	@ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
//	protected ResponseEntity<Object> errorHandler(NullPointerException ex, WebRequest req){
//		//WebRequest will have the information for the user
//		
//		MyErrorResponse errorMap=new MyErrorResponse();
//		errorMap.setMessage(ex.getMessage());
//		errorMap.setErrorCode("406");
//		errorMap.setTime(new java.util.Date());
//		
//		return handleExceptionInternal(ex,errorMap,new HttpHeaders(),HttpStatus.NOT_ACCEPTABLE,req);
//	}
	
//	@ExceptionHandler(value= {Exception.class})
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	protected ResponseEntity<Object> GenericHandler(Exception ex, WebRequest req){
//		//WebRequest will have the information for the user
//		
//		MyErrorResponse errorMap=new MyErrorResponse();
//		errorMap.setMessage(ex.getMessage());
//		errorMap.setErrorCode("404");
//		errorMap.setTime(new java.util.Date());
//		
//		return handleExceptionInternal(ex,errorMap,new HttpHeaders(),HttpStatus.NOT_FOUND,req);
//	}
	
//	@ExceptionHandler(value= {InvalidValueException.class})
//	@ResponseStatus(HttpStatus.BAD_REQUEST)
//	protected ResponseEntity<Object> definedErrorHandler(NullPointerException ex, WebRequest req){
//		//WebRequest will have the information for the user
//		
//		MyErrorResponse errorMap=new MyErrorResponse();
//		errorMap.setMessage(ex.getMessage());
//		errorMap.setErrorCode("400");
//		errorMap.setTime(new java.util.Date());
//		
//		return handleExceptionInternal(ex,errorMap,new HttpHeaders(),HttpStatus.BAD_REQUEST,req);
//	}
	
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//	@ResponseStatus(HttpStatus.BAD_REQUEST)
//	public Map<String,String> handleInvalidArguements(MethodArgumentNotValidException ex){
//		//WebRequest will have the information for the user
//		Map<String,String> errorMap = new HashMap<>();
//		
//		ex.getBindingResult().getFieldErrors().forEach (error -> {
//			errorMap.put(error.getField(),error.getDefaultMessage());
//		});
//	
//		
//		return errorMap;
//	}
	
	
	@ExceptionHandler(ProductNotFoundException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public Map<String,String> handleInvalidArguements(ProductNotFoundException ex){
		//WebRequest will have the information for the user
		Map<String,String> errorMap = new HashMap<>();
		

		errorMap.put("error message",ex.getMessage());
	
		
		return errorMap;
	}	
}
