package com.spring.boot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.spring.boot.dto.ProductRequest;
import com.spring.boot.entity.Product;
import com.spring.boot.exceptions.ProductNotFoundException;
import com.spring.boot.repository.ProductRepository;

@Service
//@PropertySource("Connection.properties")
public class ProductService {
    
	@Autowired
    ProductRepository repository;
    
    public List<Product> getProducts(){
        return repository.findAll();
    }
    public Product findById(Long id) throws ProductNotFoundException{
    	Optional<Product> optional=repository.findById(id);
    	if(optional.isPresent())
    	return optional.get();
    	else {
    		throw new ProductNotFoundException("No such product");
    	}
    }
    public Product addProduct(Product P) {
    	
    	return repository.save(P);
    }
//    public Product addProduct(ProductRequest PDTO) {
//    	Product pEntity = Product.builder()
//    			.id(0).name(PDTO.getName())
//    			.description(PDTO.getDescription())
//    			.price(PDTO.getPrice())
//    			.quantity(PDTO.getQuantity())
//    			.build();
//    	return repository.save(pEntity);
//    }
    
    
    public Product modifyProduct(Product P) {
    	return repository.save(P);
    }
    
    public void deleteProductById(Long pid) {
    	repository.deleteById(pid);
    }
    
    public Product getByName(String name) {
    	return repository.findByName(name);
    }
    
    public List<Product> findByPriceBetween(double p, double p2){
    	return repository.findByPriceBetween(p, p2);
    }
    
    public List<Product> findByQuantityLessThan(int q){
    	return repository.findByQuantityLessThan(q);
    }
    
    public List<Product> findByQuantityIn(List<Integer> q){
    	return repository.findByQuantityIn(q);
    }
    
    public List<Product> findByNameInOrderByPriceDesc(List<String> name){
    	return repository.findByNameInOrderByPriceDesc(name);
    }
    
    public List<Product> findByNameLike(String q){
    	return repository.findByNameLike(q);
    }
    
    
    
}
