package com.spring.boot.controller;

import com.spring.boot.exceptions.*;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot.dto.ProductRequest;
import com.spring.boot.entity.Product;
import com.spring.boot.service.ProductService;

import jakarta.validation.Valid;
import org.springframework.http.*;

@RestController
@RequestMapping("/product/api/1.0")
public class ProductController {
    @Autowired
    ProductService pservice;
    
//    @GetMapping("/catalog")
    
    @GetMapping
    @RequestMapping(value ="/catalog", 
//    consumes = {MediaType.APPLICATION_JSON_VALUE},
    //Consumes should not be present in the Get Mapping as no media is being consumed here and it is more
    //relevant for post mapping
    produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE})
    public List<Product> productList() throws Exception{
//    	throw new Exception("Rajeev ka error");
        return pservice.getProducts();
//    	return null;
    }
    
//    @PostMapping("/persist")
//    @ResponseStatus(HttpStatus.CREATED)
//    public void persist(@RequestBody Product P) {
////    	return pservice.addProduct(P);
//    	pservice.addProduct(P);
//    }
    
    @PostMapping
    @RequestMapping(value ="/persist")
//    , 
//    consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE},
//    produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE},
//    headers= {})
    public Product persist(@RequestBody @Valid Product P) {
    	

    	
    	return pservice.addProduct(P);
    	
    }
    
    @PostMapping
    @RequestMapping(value ="/trial", 
    consumes = {MediaType.TEXT_PLAIN_VALUE},
    produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE})
    public String trial(@RequestBody String s) {
    	return "abc"+s;
    }
    
    
//    @PostMapping("/persist")
//    public ResponseEntity<Product> persist(@RequestBody Product P) {
//    	
//    	Product tempProduct=pservice.addProduct(P);
//    	HttpHeaders myhead=new HttpHeaders();
//    	myhead.add("xx-my-header","today is hehe");
////    	return ResponseEntity.status(HttpStatus.CREATED)
////    			.headers(myhead)    			
////    			.body(tempProduct);
//    	
//    	return ResponseEntity.status(201).body(tempProduct);
//    	
////    	return ResponseEntity.ok(tempProduct);
//    	
//    }
    
//    @PostMapping("/addp")
//    public void addProducts(@RequestBody List<Product> products) {
//        for (Product p : products) {
//            pservice.addProduct(p);
//        }
//    }
    
    @DeleteMapping("/del/{pid}")
    public String delProducts(@PathVariable Long pid) 
//    		throws InvalidValueException
    {
//    	throw new InvalidValueException(pid + " Not found hehe");
    	 pservice.deleteProductById(pid);
    	 return "del";
    }
    
    @GetMapping("/getbyid/{pid}")
    public Product fetchProduct(@PathVariable Long pid) throws ProductNotFoundException {
    	return pservice.findById(pid);
    }
    
    @PutMapping("/modify")
    public Product changeProduct(@RequestBody Product P) {
    	return pservice.modifyProduct(P);
    }
    
    @GetMapping("/findbyname/{name}")
    public Product getByName(@PathVariable String name) {
    	return pservice.getByName(name);
    }
    
    @GetMapping("/findbyrange/{p1}&{p2}")
    public List<Product> findByPriceBetween(@PathVariable double p1,@PathVariable double p2){
    	return pservice.findByPriceBetween(p1, p2);
    }
    
    @GetMapping("/findquantitylessthan/{q}")
    public List<Product> findByQuantityLessThan(@PathVariable int q){
    	return pservice.findByQuantityLessThan(q);
    }
    
    @GetMapping("/getqty/{q}")
    public List<Product> findByQuantityList(@PathVariable List<Integer> q){
    	return pservice.findByQuantityIn(q);
    }
    
    @GetMapping("/getbysort/{q}")
    public List<Product> findByNameInOrderByPriceDesc(@PathVariable List<String> q){
    	return pservice.findByNameInOrderByPriceDesc(q);
    }
    
    @GetMapping("/getnamebylike/{q}")
    public List<Product> findByNameLike(@PathVariable String q){
    	return pservice.findByNameLike(q);
    }
    

}