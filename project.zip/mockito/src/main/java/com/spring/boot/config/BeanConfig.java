package com.spring.boot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

//This bean will be instantiated only when the given profile is active
@Component
@Profile("test")
public class BeanConfig {

	public BeanConfig() {
		System.out.println("Instantiating BeanConfig....");
	}
	
	@Bean
	public String dataSourceP(){
		return "using test ";
	}
}
