package com.spring.boot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Description;

import com.spring.boot.entity.Product;
import com.spring.boot.exceptions.ProductNotFoundException;
import com.spring.boot.repository.ProductRepository;
import com.spring.boot.service.ProductService;

@SpringBootTest
class MockitoApplicationTests {

	@Autowired
	ProductService service;
	
	@MockBean
	ProductRepository repo;
	@Test
	public void findAllTest() {
		when(repo.findAll()).thenReturn(
				Stream.of(new Product(101,"aa","aa",10,100),
						new Product(102,"bb","bb",20,200))
				.collect(Collectors.toList())
				);
		assertThat(2==service.getProducts().size());
	}
	
	@Test
	public void findByIdTest() throws ProductNotFoundException {
		Optional <Product> product = Optional.of(
				new Product(1L,"aa","aa",20,200));
		when(repo.findById(1L)).thenReturn(product);
		
		Product result=service.findById(1L);
		assertEquals(product.get(),result);
				
	}
	@Test
	public void finById_ProductNotFound() throws ProductNotFoundException {
		when(repo.findById(1011L)).thenThrow(new ProductNotFoundException("No such product"));
		
		assertThrows(ProductNotFoundException.class,() -> service.findById(1011L));
	}
	
	@Description("Delete a product from DB")
    @Test
    public void deleteProductTest() {
        Product p = new Product(1L, "aa", "aa", 10, 100);
        repo.deleteById(1l);
        verify(repo, times(1)).deleteById(1L);
    }

}
