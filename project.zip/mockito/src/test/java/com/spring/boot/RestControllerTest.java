package com.spring.boot;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.boot.controller.ProductController;
import com.spring.boot.entity.Product;
import com.spring.boot.service.ProductService;

@WebMvcTest(ProductController.class)
public class RestControllerTest {

	@Autowired
	private MockMvc mvc;
	
	@MockBean
	ProductService service;
	
	@Test
	public void addProductTest() throws Exception {
		Product product=new Product(105L,"aa","aaa",20,200);
		when(service.addProduct(Mockito.any(Product.class)))
		.thenReturn(product);
		
		mvc.perform(
				MockMvcRequestBuilders
				.post("/product/api/1.0/persist")
				.content(new ObjectMapper().writeValueAsString(product))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
		.andExpect(status().is2xxSuccessful())
		.andExpect(MockMvcResultMatchers.jsonPath("$.id").value(105L))
		.andExpect(MockMvcResultMatchers.jsonPath("$.id").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.name").value("aa"));
	}
}
