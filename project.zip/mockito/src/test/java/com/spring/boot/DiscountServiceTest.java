package com.spring.boot;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.web.WebAppConfiguration;

import com.spring.boot.service.DiscountService;

@SpringBootTest
//@ExtendWith(MockitoExtension.class)
@WebAppConfiguration
class DiscountServiceTest {

//	@Autowired
	 @InjectMocks
	DiscountService dservice;
	
	
	@Test
	public void testCalculateDiscount_ValidPromoCode() {
		double discount=dservice.computeDiscount(10000, "THANKSGIVING");
		assertEquals(1500.00,discount);
	}
//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}

}
