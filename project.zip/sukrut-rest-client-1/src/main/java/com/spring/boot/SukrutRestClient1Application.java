package com.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.spring.boot.model.Product;

@SpringBootApplication
public class SukrutRestClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(SukrutRestClient1Application.class, args);
		
		Product p=new Product(127L,"abc", "123", 0, 0);
	}
	
	@Bean
	public RestTemplate makeTemplate() {
		return new RestTemplate();
	}

}
