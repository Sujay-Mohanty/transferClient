package com.spring.boot.model;

public record Product(Long id,String name, String description, int quantity,double price){

	
}
