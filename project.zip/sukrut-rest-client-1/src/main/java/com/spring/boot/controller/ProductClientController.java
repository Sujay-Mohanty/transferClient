package com.spring.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.spring.boot.model.Product;

//import com.spring.boot.model.Product;


//Client URL
//localhost:8096/product/api/client/viewcatalog
@RestController
@RequestMapping("/product/api/client")
public class ProductClientController {

	@Autowired
	RestTemplate template;
	
	@GetMapping("/viewcatalog/{pid}")
	public Product catalogById(@PathVariable("pid") long pid){
		
		String url="http://localhost:8095/product/api/1.0/getbyid/"+pid;
		return template.getForObject(url, Product.class);
		//return type of class is the second arguement
		
//		return null;
	}
	
	@GetMapping("/delcatalog/{pid}")
	public String catalogdel(@PathVariable long pid) {
		String url="http://localhost:8095/product/api/1.0/del/"+pid;
//		template.delete(url);
//		return "Abhishek ki Success";
		ResponseEntity <String> response = template.exchange(
		        url,
		        HttpMethod.DELETE,
		        null,
		        String.class
		    );
//			response.
		    return response.getBody();
	}
	
	
	@GetMapping("/viewcatalogall")
	public List<Product>catalog(){
		String url="http://localhost:8095/product/api/1.0/catalog";
		ResponseEntity<List<Product>> response = template.exchange(
		        url,
		        HttpMethod.GET,
		        null,
		        new ParameterizedTypeReference<List<Product>>() {}
		    );

		    return response.getBody();
	}
	
	@GetMapping("/viewcatalog/byname/{name}")
	public Product catalogs(@PathVariable String name){
		String url="http://localhost:8095/product/api/1.0/findbyname/" + name;
//		return template.getForObject(url, Product.class);
		ResponseEntity <Product> response = template.exchange(
		        url,
		        HttpMethod.GET,
		        null,
		        new ParameterizedTypeReference <Product>() {}
		    );

		    return response.getBody();
	}



}