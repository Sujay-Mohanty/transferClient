package com.boot.everify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverificationGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverificationGatewayApplication.class, args);
	}

}
