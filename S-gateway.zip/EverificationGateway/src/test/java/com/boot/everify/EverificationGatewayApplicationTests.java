package com.boot.everify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverificationGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
